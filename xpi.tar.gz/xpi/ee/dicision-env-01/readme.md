# EE
## Login na redhat
    podman login registry.redhat.io -u lagomes@redhat.com -p xxx
    podman login -u='lagomes' -p='CgYYNSRjdRxwsmrW8EFaqpfY/RCo3gP0GFlKtXY2uhnL8yfmmi5qEj+tO7uYUsID' quay.io
## Build
    ansible-builder build -t quay.io/lagomes/de-exemplo:v1 -v 3
## Enviando para o hub
    podman push quay.io/lagomes/de-exemplo:v1
## Test
    podman container run -it quay.io/lagomes/de-exemplo:v1 ansible-galaxy collection list 